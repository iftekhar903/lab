#include<stdio.h>
#include<math.h>
int main()
{
 int A,B,C,Equation;
 float D;
 printf("Enter the value For A B C D. (D value should be a float number)  = ");
 scanf("%d %d %d %f",&A,&B,&C,&D);
 Equation =pow(A,C)+(B*A)-(D/3);
 printf("The result of this Equation = %d",Equation);
 return 0;
}
