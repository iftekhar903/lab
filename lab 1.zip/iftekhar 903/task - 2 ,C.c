#include<stdio.h>
int main()
{
    int sum=0;
    printf("first number=54\n second number =56\n");
    sum=54+56;
    printf("the result is=%d",sum);
    return 0;

}
