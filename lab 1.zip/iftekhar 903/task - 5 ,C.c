#include<stdio.h>
#include<math.h>
int main()
{
int x,y,res;
printf("Enter the value of X = ");
scanf("%d",&x);

printf("Enter the value of Y = ");
scanf("%d",&y);

printf("%d^%d",x,y);

res = pow(x,y);

printf(" result = %d",res);
return 0;

}
