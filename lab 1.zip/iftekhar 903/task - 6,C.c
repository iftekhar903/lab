#include<stdio.h>
int main ()
{
    int total,result,division;
    printf("Enter the total weight of the Shipment = ");
    scanf("%d",&total);
    division =total/4;
    result=division*4;
    printf("The maximum load the boat can take = %d",result);
    return 0;
}
