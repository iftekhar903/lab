#include<stdio.h>
int main()
{
    int x,div,rem;

    printf("Enter the Numbers Of Chocolates = ");
    scanf("%d",&x);

    div = x/3;
    printf("Each friend will receive %d chocolates\n",div);

    rem = x%3;
    printf("The number of remaining Chocolates %d",rem);

    return 0;
}
