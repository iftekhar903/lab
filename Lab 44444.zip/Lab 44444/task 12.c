1
myArray = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
2
index1 = 0
3
index2 = 0
4
index1 = 1
5
while(index1<10): //index1=1,2,3
6
myArray[index1] = index1+4//myArray[1,2,3]=5,6,7
7
index2 = 1//1,2
8
while(index2<index1)://1<2 2<3
9
myArray[index1] = myArray[index1] + myArray[index2]-index1//myArray[2]=myArray[2]+myArray[1]-2
10
index2 = index2+1//2
11
print(myArray[index1])//6,11,
12
index1 = index1+1//3,4
