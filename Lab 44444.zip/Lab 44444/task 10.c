#include<stdio.h>
int main()
{
  int n;
  printf("Enter size= ");
  scanf("%d",&n);
  int a[n],a2[n],i,j,k;
  printf("Enter Array = ");
  for(i=0;i<n;i++)
  {
         scanf("%d",&a[i]);
  }
  printf("Original array= ");
  for(i=0;i<n;i++)
  {
         printf("%d,",a[i]);

  }
printf("\nModified array= ");

for(i=0;i<n;i++)//2 3 4 2 5 7
{
  for(j=i+1;j<n;j++) //j=3
  {
         if(a[i]==a[j])
         {
              for(k=j;k<n;k++) //k=3 4 5
              {
                     a[k]=a[k+1];//k=4 5
              }
              n--;
              j--;
         }
  }
}
for(i=0;i<n;i++)
{
       printf("%d,",a[i]);
}

  return 0;
  }



