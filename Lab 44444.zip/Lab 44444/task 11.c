#include<stdio.h>
int main()
{
  int n1,n2;
  printf("Enter 1st Arry Size= ");
  scanf("%d",&n1);
  int a1[n1],i;
  printf("Enter 1st Array= ");
  for(i=0;i<n1;i++)
  {
         scanf("%d",&a1[i]);
  }
    printf("\nEnter 2nd Arry Size= ");
    scanf("%d",&n2);
    int a2[n2],j;
     printf("Enter 2nd Array= ");
     for(j=0;j<n2;j++)
  {
         scanf("%d",&a2[j]);
  }
  //1 3 5 7 9
  //2 7 4 6 8
  for(i=0;i<n1;i++)
  {
         for(j=0;j<n2;j++)
         {
                if(a1[i]==a2[j])
                {
                     printf("True");
                     n1=i;
                     n2=j;
                     break;
                }


          else if(a1[i]!=a2[j])
          {
               printf("False");
          n1=i;
          n2=j;
          break;
          }


              break;

         }




  }

  return 0;
}

