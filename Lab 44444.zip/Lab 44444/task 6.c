#include<stdio.h>
int main()
{
  int i,n,j=0;
  printf("Enter Array Size= ");
  scanf("%d",&n);
  int a[n],max;
  for(i=0;i<n;i++)
  {
         scanf("%d",&a[i]);
  }
  max=a[0];
  for(i=1;i<n;i++)
  {
         if(max<a[i])
         {
                max=a[i];
                j=i;
         }

  }
  printf("\nMy array");
  for(i=0;i<n;i++)
  {
         printf("%d,",a[i]);
  }
  printf("Largest number in the array is %d which was found at index %d.",max,j);

  return 0;
}

