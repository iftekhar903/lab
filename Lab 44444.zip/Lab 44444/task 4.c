#include<stdio.h>
int main()
{
  int i,j,n;
  printf("Enter Your array Size= ");
  scanf("%d",&n);
  int a[n];
  for(i=0;i<n;i++)
  {
         scanf("%d",&a[i]);

  }
  for(i=0,j=0;i<n,j<n;i++,j++)
  {
          a[j]=a[i]*a[i];
  }
 for(j=0;j<n;j++)
  {
         printf("%d,",a[j]);
  }


  return 0;
}

