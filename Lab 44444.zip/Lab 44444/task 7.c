#include<stdio.h>
int main()
{
  int n1,n2;
  printf("Enter 1st Arry Size= ");
  scanf("%d",&n1);
  int a1[n1],i;
  printf("Enter 1st Array= ");
  for(i=0;i<n1;i++)
  {
         scanf("%d",&a1[i]);
  }
    printf("\nEnter 2nd Arry Size= ");
    scanf("%d",&n2);
    int a2[n2],j;
     printf("Enter 2nd Array= ");
     for(j=0;j<n2;j++)
  {
         scanf("%d",&a2[j]);
  }
for(i=0;i<n1;i++)
  {
         printf("%d,",a1[i]);
  }
for(j=0;j<n2;j++)
 {
         printf("%d,",a2[j]);
  }

  return 0;
}

