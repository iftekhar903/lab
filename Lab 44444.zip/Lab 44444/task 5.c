#include<stdio.h>
int main()
{
  int a[]={0,1,2,3,4,5,6,7};//jehetu 2,4,6 number array tae space ase tai egula remove korbo
int i;
for(i=0;i<8;i++)
{
        if(a[i]%2!=0)
        {
               printf("%d,",a[i]);
        }

}


  return 0;
}

