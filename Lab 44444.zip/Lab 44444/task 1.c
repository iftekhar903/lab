#include<stdio.h>
int main()
{
    int a[6],i,j;
    for(i=0; i<5; i++)
    {
        scanf("%d",&a[i]);
        for(j=0; j<=i; j++)
        {
            if(a[j]==a[0])
            {
                printf("%d",a[j]);
            }
            else
            {
                printf(",%d",a[j]);
            }
        }
    }



    return 0;
}
