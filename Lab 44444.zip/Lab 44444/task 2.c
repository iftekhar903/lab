#include<stdio.h>
int main()
{
  int i,j,n;
  printf("Enter Array Size= ");
  scanf("%d",&n);
  if(n<4)
  {
         printf("Not possible");
  }
  else{
  int a[n];
  printf("\nEnter Your Array");
  for(i=0;i<n;i++)
  {
         scanf("%d",&a[i]);
  }
  for(i=2;i<n-2;i++)
  {
         printf("%d,",a[i]);
  }
  }

  return 0;
}

