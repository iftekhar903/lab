#include<stdio.h>
#include<math.h>
int main()
{
    float redius,area,cir;
    printf("inter redius value:");
    scanf("%f",&redius);
    area=M_PI*(pow(redius,2));
    cir=2*M_PI*redius;
    printf("area is =%f\n cir=%f",area,cir);
    return 0;





}
