#include<stdio.h>
int main()
{
    int x,y,subtracts;

    printf("Enter two Numbers for Subtracts = ");
    scanf("%d %d",&x,&y);

    if(x>y){
        subtracts = x-y;
        printf("%d",subtracts);
    }
    else if(x<y){
        subtracts = y-x;
        printf("%d",subtracts);
    }
        return 0;
}
