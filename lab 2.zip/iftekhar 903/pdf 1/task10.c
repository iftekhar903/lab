#include<stdio.h>
int main()
{
    int x,less,more;

    printf("Enter hours of worked = ");
    scanf("%d",&x);

    if(x<0){
        printf("Hour cannot be negative");
    }
    else if(x>168)
        printf("Impossible to work more than 168 hours weekly");

   else if(x<=40){
        less = x*200;
        printf("Salary = %d ",less);
    }
    else if(x>40){
        more = 8000 + (x-40) * 300;
        printf("Salary = %d",more);
    }
    return 0;
}
