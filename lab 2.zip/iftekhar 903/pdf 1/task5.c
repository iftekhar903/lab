#include<stdio.h>
int main()
{
    int x;

    printf("Enter any integer Number to check it is even or odd =  ");
    scanf("%d",&x);

    if(x%2==0)
    {
        printf("It is a even Number");
    }
    else
        printf("It is a odd Number");
    return 0;
}
