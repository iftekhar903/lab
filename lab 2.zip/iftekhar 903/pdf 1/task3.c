#include<stdio.h>
int main()
{
    int x,y;

    printf("Enter First Number = ");
    scanf("%d",&x);

    printf("Enter the second Number = ");
    scanf("%d",&y);

    if(x>y)
    {
        printf("First is greater");
    }
    else if(x<y)
    {
        printf("Second is greater");
    }
    else
        printf("The Numbers are equal");

    return 0;


}
