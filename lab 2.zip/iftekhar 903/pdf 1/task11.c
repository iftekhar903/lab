#include<stdio.h>
int main()
{
    double L;
    float s;

    printf("Enter S = ");
    scanf("%f",&s);
    if(s<100){
            L = 3000 - (125*(s*s));
        printf("%.2lf",L);
    }
    else if(s>=100){
         L = 12000/(4+(s*s)/14900);
        printf("%.14lf",L);
    }
    return 0;
}

