#include<stdio.h>
int main()
{
    int sec,hour,min,second,se_co;

    printf("Enter the Number of seconds : ");
    scanf("%d",&sec);

    hour = sec/3600;
    printf("Hours : %d .",hour);

    second = sec%3600;
    min = second/60;
    printf("Minutes : %d .",min);

    se_co = second%60;
    printf("Seconds : %d",se_co);

    return 0;
}
