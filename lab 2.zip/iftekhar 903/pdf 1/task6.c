#include<stdio.h>
int main()
{
    int x;

    printf("Enter any Integer to check is it multiple 2 or 5 = ");
    scanf("%d",&x);

    if(x%2==0 || x%5==0)
        printf("%d",x);
    else
        printf("Not a multiple of 2 or 5");

    return 0;

}
