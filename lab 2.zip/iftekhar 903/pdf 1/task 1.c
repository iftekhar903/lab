#include<stdio.h>
int main()
{
    int x,y,sum,pro,diff;
    printf("int value of x:");
    scanf("%d",&x);
    printf("int value of y:");
    scanf("%d",&y);
    sum=x+y;
    pro=x*y;
    diff=x-y;
    printf("%d\n%d\n%d\n",sum,pro,diff);
    return 0;




}
