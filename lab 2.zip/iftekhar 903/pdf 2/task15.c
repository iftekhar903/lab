                                                                                                                                                                                                                                                                                                                                                                                    #include<stdio.h>
int main()
{
    float cg;
    int cr;

    printf("Enter CGPA = ");
    scanf("%f",&cg);

    printf("Enter Completed Number of CREDIT = ");
    scanf("%d",&cr);

    if(cg<3.80 || cr<30){
        printf("The student is not eligible for a waiver");
    }

    else if(cg>=3.80 && cg<=3.89){
        printf("The student is eligible for a waiver of 25 percent");
    }
    else if(cg>=3.90 && cg<=3.94){
        printf("The student is eligible for a waiver of 50 percent");
    }
    else if(cg>=3.95 && cg<4.00){
        printf("The student is eligible for a waiver of 75 percent");
    }
    else if(cg==4.00){
        printf("The student is eligible for a waiver of 100 percent");
    }
       return 0;
}
