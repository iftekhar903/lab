#include<stdio.h>
int main()
{
    int marks;

    printf("Enter the mark : ");
    scanf("%d",&marks);

    if(marks>100 || marks<0)
    {
        printf("Invalid marks");
    }
    else if(marks<50)
    {

        printf("F");
    }
    else if(marks>=50 && marks<=59)
    {
        printf("E");
    }
    else if(marks>=60 && marks<=69)
    {

        printf("D");
    }
    else if(marks>=70 && marks<=79)
    {
        printf("C");
    }
    else if(marks>=80 && marks<=89)
    {
        printf("B");
    }
    else if(marks<=100 && marks>=90)
    {
        printf("A");
    }
    return 0;
}
