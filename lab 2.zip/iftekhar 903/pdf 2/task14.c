#include<stdio.h>
int main()
{
    int t,time;
    float distance,vel,d;

    printf("Enter Distance 'in meter' : ");
    scanf("%f",&d);

    printf("Enter Time 'in seconds' : ");
    scanf("%d",&t);

    time = t/3600;
    distance = d/1000;

    vel = distance/time;
    printf("%.1f km/h \n",vel);

    if(vel<60)
    {
        printf("Too slow.Needs more changes");
    }
    else if(vel>=60 && vel<=90)
    {
        printf("Velocity is okay. The car is ready");
    }
    else if(vel>90)
    {
        printf("Too fast.Only a few changes should suffice");
    }
    return 0;
}
