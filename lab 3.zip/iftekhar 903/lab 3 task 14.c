#include<stdio.h>
int main()
{
    int n,sum=0,i;

    printf("Enter a Number to see that it is perfect Number or Not a perfect Number = ");
    scanf("%d",&n);

    for(i=1;i<=n/2;i++)
    {
        if(n%i==0)
        {
            sum = sum + i;

        if(n==sum)

            printf("It is a perfect Number");
        }
        else
            printf("It is not a perfect Number");
    }
    return 0;

}

