#include<stdio.h>
int main()
{
  int i,num,sum=0;
  printf("enter the number:");
  scanf("%d",&num);
  for(i=7;i<=num;i=i+7)
  {
    if(i%7==0);{
    printf("%d, ",i);
    sum=sum+i;}

  }
   printf("\nthe sum is %d ",sum);








}
