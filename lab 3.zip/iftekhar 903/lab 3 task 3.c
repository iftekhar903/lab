#include<stdio.h>
int main()
{
    int i,sum,num;

    printf("Numbers are : ");

    for(i=63;i<=600;i=i+63){
       sum +=i;

       printf(" %d  ",i);
    }
    printf("\nSum is  : %d",sum);

    return 0;
}
