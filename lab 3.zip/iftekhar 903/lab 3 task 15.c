#include<stdio.h>
int main()
{
    int num,i,count=0;
    printf("Enter any positive Number for identify is it prime or not prime : ");
    scanf("%d",&num);

    for(i=2; i<num; i++)
    {
        if(num%i==0)
        {
            count++;
            break;
        }
    }
    if(count==0)
        printf("%d Prime Number",num);
    else
        printf("%d Not a prime Number",num);

    getch();
}

