#include<stdio.h>
int main()
{

int i;
for(i=24;i>=-6;i=i-6)
    printf("%d, ",i);



}
