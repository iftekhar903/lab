#include <stdio.h>

int main() {
    int num1, num2, num3, num4, num5,i;

    printf("Enter 5 numbers:\n");


    scanf("%d", &num1);
    printf("Number 1 = %d\n", num1);

    scanf("%d", &num2);
    printf("Number 2 = %d + %d = %d\n",num1,num2, num1 + num2);

    scanf("%d", &num3);
    printf("Number 3 = %d + %d + %d = %d\n",num1,num2,num3, num1 + num2 + num3);

    scanf("%d", &num4);
    printf("Number 4 = %d + %d + %d + %d = %d\n",num1,num2,num3,num4, num1 + num2 + num3 + num4);

    scanf("%d", &num5);
    printf("Number 5 = %d + %d + %d + %d + %d = %d\n",num1,num2,num3,num4,num5 , num1 + num2 + num3 + num4 + num5);


    return 0;
}
