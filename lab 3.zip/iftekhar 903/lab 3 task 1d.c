#include<stdio.h>
int main()
{

 int i,l;
 for(i=18;i<=63;i=i+9)

         if(i%2!=0)
            {
            l=i*(-1);
            printf("%d ",l);
            }
        else if(i%2==0)
            {
            printf("%d ",i);
            }

}

