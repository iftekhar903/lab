#include<stdio.h>
int main()
{

int i;
for(i=18;i<=63;i=i+9)
    printf("%d, ",i);

}

