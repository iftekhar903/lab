#include<stdio.h>
int main()
{
    int i,sum;

    printf("Numbers Are : ");

    for(i=1;i<=600;i++){
        if((i%7==0 || i%9==0)&& !(i%7==0 && i%9==0)){
            printf("%d ",i);

            sum+=i;
        }
    }
    printf("\nSum = %d",sum);

    return 0;
}
