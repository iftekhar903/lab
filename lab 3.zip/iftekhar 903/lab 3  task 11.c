#include<stdio.h>
int main()
{
    int n,i=n,count=0;

    printf("Enter  Number : ");
    scanf("%d",&n);

    for(i=1;i<=n;i++){
        if(i){
        n/=10;
        count++;
        }
    }
     printf("%d",count);
}
