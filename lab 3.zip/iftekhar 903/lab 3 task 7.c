#include<stdio.h>
int main()
{

    int x,i,sum=0,count=0;
    float avg;

    printf("Enter Ten Numbers\n");

    for(i=0;i<10;i++){
        printf("Enter number %d = ",i+1);
            scanf("%d",&x);

            if(x%2 != 0){
            count++;
            sum = sum+x;
            }
    }
    avg = (float)sum/count;
    printf("The total of the odd numbers is %d\n",sum);
    printf("The Average is %f ",avg);

    return 0;
}



