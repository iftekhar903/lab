#include<stdio.h>
int main()
{
    char ch;
    int n,i;
    printf("enter the car =");
    scanf("%c, ",&ch);
    printf("enter the how many time print:");
    scanf("%d, ",&n);

    printf("%c,%d\n",ch,n);
    for (i=1;i<=n;i=i+1)
        {
        printf("c\n",ch);
        }
}
