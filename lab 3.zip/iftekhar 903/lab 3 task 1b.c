#include<stdio.h>
int main()
{

int i;
for(i=-10;i<=20;i=i+5)
    printf("%d, ",i);



}

